import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient;
  music:MusicStore[]=[];
  constructor( http:HttpClient) { 
    this.http=http;
    this.fetchDetails();
  }
  fetched:boolean=false;

  fetchDetails()
  {
    this.http.get('./assets/MusicStore.json')
    .subscribe
    (
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getStore():MusicStore[]
  {
    return this.music;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new MusicStore(o.pid,o.pname,o.pprice,o.pcategory);
      this.music.push(e);
    }
  }
  add(e:MusicStore){
    this.music.push(e);
  }
}
export class MusicStore{
  AlbumID:number;
  Title:string;
  Artist:string;
  Price:number;
  constructor( AlbumID:number,Title:string,Artist:string,Price:number){
    this.AlbumID=AlbumID;
    this.Title=Title;
    this.Artist=Artist;
    this.Price=Price;
  }
}