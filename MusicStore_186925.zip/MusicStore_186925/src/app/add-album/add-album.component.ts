import { Component, OnInit } from '@angular/core';
import { MyServiceService, MusicStore } from '../my-service.service';

@Component({
  selector: 'app-add-album',
  templateUrl: './add-album.component.html',
  styleUrls: ['./add-album.component.css']
})
export class AddAlbumComponent implements OnInit {
  service:MyServiceService;
  music:MusicStore;
  constructor( service:MyServiceService) {
    this.service=service;
   }

  ngOnInit() {
  }
  add(data:any){
    this.music=new MusicStore(data.AlbumID,data.Title,data.Artist,data.Price);
    this.service.add(this.music);
}
}