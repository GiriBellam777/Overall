package enquiryPageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CoachingClassEnquiryPageFactory {
	
	WebDriver driver;
	
	@FindBy(how=How.NAME,using="fname")
	@CacheLookup //for speeding up the processes
	WebElement firstName;  

	@FindBy(how=How.NAME,using="lname")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(how=How.NAME,using="email")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.NAME,using="mobile")
	@CacheLookup
	WebElement mobileNumber;
	
	@FindBy(how=How.NAME, using="D6")
	@CacheLookup
	WebElement tutionType;
	
	@FindBy(how=How.NAME, using="D5")
	@CacheLookup
	WebElement cityPreference;
	
	@FindBy(how=How.NAME, using="D4")
	@CacheLookup
	WebElement modeOfLearning;
	
	@FindBy(how=How.NAME, using="enqdetails")
	@CacheLookup
	WebElement enquiry;
	
	@FindBy(how=How.ID, using="Submit1")
	@CacheLookup
	WebElement submitButton;
	
	@FindBy(how=How.ID, using="Submit2")
	@CacheLookup
	WebElement resetButton;
	
	public CoachingClassEnquiryPageFactory(WebDriver driver) {
		// TODO Auto-generated constructor stub
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmailId(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber.sendKeys(mobileNumber);
	}

	public WebElement getTutionType() {
		return tutionType;
	}

	public void setTutionType(String tutionType) {
		this.tutionType.sendKeys(tutionType);
	}

	public WebElement getCityPreference() {
		return cityPreference;
	}

	public void setCityPreference(String cityPreference) {
		this.cityPreference.sendKeys(cityPreference);
	}

	public WebElement getModeOfLearning() {
		return modeOfLearning;
	}

	public void setModeOflearning(String modeOfLearning) {
		this.modeOfLearning.sendKeys(modeOfLearning);
	}

	public WebElement getEnquiry() {
		return enquiry;
	}

	public void setEnquiry(String enquiry) {
		this.enquiry.sendKeys(enquiry);
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

	public WebElement getResetButton() {
		return resetButton;
	}

	public void setResetButton() {
		this.resetButton.click();
	}

	public void getSubmitButton(String string) {
		// TODO Auto-generated method stub
		
	}

	
}
