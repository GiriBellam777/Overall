package classEnquiry;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import enquiryPageBean.CoachingClassEnquiryPageFactory;


public class CoachingClassEnquiryStepDefinition {
	private WebDriver driver;
	private CoachingClassEnquiryPageFactory coachingClassEnquiryPageFactory;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\htatta\\Desktop\\seleniumjars\\chromedriver\\chromedriver.exe");
		
		driver= new ChromeDriver();
	}
	
	@Given("^User is on \"([^\"]*)\" Page$")
	public void user_is_on_Page(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.get("C:/Users/girprasa/Desktop/BDDCaseStudyFinal/hotelbooking.html");
		coachingClassEnquiryPageFactory = new CoachingClassEnquiryPageFactory(driver);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	    
	}

	@Then("^displays 'First Name must be filled out'$")
	public void displays_First_Name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="First Name must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	    
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("giri");
		coachingClassEnquiryPageFactory.setLastName("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	    
	}

	@Then("^displays 'Last Name must be filled out'$")
	public void displays_Last_Name_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Last Name must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	    
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("bellam");
		coachingClassEnquiryPageFactory.setLastName("Giri");
		coachingClassEnquiryPageFactory.setEmailId("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	    
	    
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Email must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	/*@When("^user enters Invalid EmailId$")
	public void user_enters_Invalid_EmailId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("Harini");
		coachingClassEnquiryPageFactory.setLastName("Vagdevi");
		coachingClassEnquiryPageFactory.setEmailId("degfsdukfh");
		coachingClassEnquiryPageFactory.setSubmitButton();
	   
	}

	@Then("^displays 'Enter a valid EmailId'$")
	public void displays_Enter_a_valid_EmailId() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter a valid emailId";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
	}*/
	
	@When("^user enters Invalid MobileNumber$")
	public void user_enters_Invalid_MobileNumber() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("Giri");
		coachingClassEnquiryPageFactory.setLastName("bellam");
		coachingClassEnquiryPageFactory.setEmailId("giribellam@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	}

	@Then("^displays 'Mobile Number must be filled out'$")
	public void displays_Mobile_Number_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Mobile must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	
	@When("^user enters alphabetic Mobile Number$")
	public void user_enters_alphabetic_Mobile_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("giri");
		coachingClassEnquiryPageFactory.setLastName("bellam");
		coachingClassEnquiryPageFactory.setEmailId("giribellam@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("wegfuihjshhf");
		coachingClassEnquiryPageFactory.setSubmitButton();
	   
	}

	@Then("^displays 'Enter numeric value'$")
	public void displays_Enter_numeric_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Enter numeric value";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();	    
	}

	@When("^user enters Invalid Mobile Number$")
	public void user_enters_Invalid_Mobile_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("giri");
		coachingClassEnquiryPageFactory.setLastName("bellam");
		coachingClassEnquiryPageFactory.setEmailId("giribellam@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("10013456788452");
		coachingClassEnquiryPageFactory.setSubmitButton();
	   
	}

	@Then("^displays 'Enter ten digit Mobile number'$")
	public void displays_Enter_ten_digit_Mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Enter 10 digit Mobile number";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	
/*	@When("^user enters Invalid MobileNum$")
	public void user_enters_Invalid_MobileNum() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("Harini");
		coachingClassEnquiryPageFactory.setLastName("Vagdevi");
		coachingClassEnquiryPageFactory.setEmailId("harinivagdevi@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("100134567882");
		coachingClassEnquiryPageFactory.setSubmitButton();	    
	}

	@Then("^displays 'Number should start with the digit (\\d+)'$")
	public void displays_Number_should_start_with_the_digit(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="it should start with 9 ";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
	}*/

/*	@When("^user enters invalid Type of Tution Required$")
	public void user_enters_invalid_Type_of_Tution_Required() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("Harini");
		coachingClassEnquiryPageFactory.setLastName("Vagdevi");
		coachingClassEnquiryPageFactory.setEmailId("harinivagdevi@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("9100137932");
		coachingClassEnquiryPageFactory.setTutionType("Select");
		coachingClassEnquiryPageFactory.setSubmitButton();
	  
	}

	@Then("^display 'Type of tution required must be filled out'$")
	public void display_Type_of_tution_required_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select the type of tution required";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
	    
	}

	@When("^user enters invalid City Preference$")
	public void user_enters_invalid_City_Preference() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("Harini");
		coachingClassEnquiryPageFactory.setLastName("Vagdevi");
		coachingClassEnquiryPageFactory.setEmailId("harinivagdevi@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("9100137932");
		coachingClassEnquiryPageFactory.setTutionType("Spoken English");
		coachingClassEnquiryPageFactory.setCityPreference("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	}

	@Then("^display 'City preference must be filled out'$")
	public void display_City_preference_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select the City Preference";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
	}

	@When("^user enters invalid Mode of Learning$")
	public void user_enters_invalid_Mode_of_Learning() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("Harini");
		coachingClassEnquiryPageFactory.setLastName("Vagdevi");
		coachingClassEnquiryPageFactory.setEmailId("harinivagdevi@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("9100137932");
		coachingClassEnquiryPageFactory.setTutionType("Spoken English");
		coachingClassEnquiryPageFactory.setCityPreference("Pune");
		coachingClassEnquiryPageFactory.setModeOflearning("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	    
	}

	@Then("^display 'Mode of learning must be filled out'$")
	public void display_Mode_of_learning_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select the Mode of learning";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
	}*/

	@When("^user enters Invalid Enquiry$")
	public void user_enters_Invalid_Enquiry() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("giri");
		coachingClassEnquiryPageFactory.setLastName("bellam");
		coachingClassEnquiryPageFactory.setEmailId("giribellami@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("9100137932");
		coachingClassEnquiryPageFactory.setTutionType("Spoken English");
		coachingClassEnquiryPageFactory.setCityPreference("Pune");
		coachingClassEnquiryPageFactory.setModeOflearning("Class room training");
		coachingClassEnquiryPageFactory.setEnquiry("");
		coachingClassEnquiryPageFactory.setSubmitButton();
	   
	}

	@Then("^display 'Enquiry details must be filled out'$")
	public void display_Enquiry_details_must_be_filled_out() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Enquiry details must be filled out";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}
	
	@When("^user enters Valid Form Details$")
	public void user_enters_Valid_Form_Details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		coachingClassEnquiryPageFactory.setFirstName("girii");
		coachingClassEnquiryPageFactory.setLastName("bellami");
		coachingClassEnquiryPageFactory.setEmailId("giribellam@gmail.com");
		coachingClassEnquiryPageFactory.setMobileNumber("9100137932");
		coachingClassEnquiryPageFactory.setTutionType("Spoken English");
		coachingClassEnquiryPageFactory.setCityPreference("Pune");
		coachingClassEnquiryPageFactory.setModeOflearning("Class room training");
		coachingClassEnquiryPageFactory.setEnquiry("Institute timings");
		coachingClassEnquiryPageFactory.setSubmitButton();
	    
	}

	@Then("^display 'Thank you for the submission'$")
	public void display_Thank_you_for_the_submission() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Thank you for submitting the online coaching Class Enquiry";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	   
	}

	/*@Then("^display 'Our Counselor will contact you soon\\.'$")
	public void display_Our_Counselor_will_contact_you_soon() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Our Counselor will contact you soon.");
		driver.close();	    
	}*/

}
